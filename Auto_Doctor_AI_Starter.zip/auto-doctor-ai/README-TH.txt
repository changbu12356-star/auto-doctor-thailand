AUTO DOCTOR AI — ชุดเว็บไซต์เริ่มต้นพร้อมเชื่อม AI

ไฟล์สำคัญ
- public/index.html : หน้าเว็บภาษาไทย รองรับมือถือ
- api/analyze.js : API ฝั่งเซิร์ฟเวอร์ เรียก AI ผ่าน OpenRouter
- vercel.json : ตั้งค่า Vercel

วิธีเผยแพร่ด้วย iPhone
1) ดาวน์โหลดและแตกไฟล์ ZIP
2) เข้า github.com แล้วสร้าง repository ใหม่ (เช่น auto-doctor-ai)
3) อัปโหลดไฟล์/โฟลเดอร์ทั้งหมดโดยคงโครงสร้างเดิม
4) เข้า vercel.com แล้วเลือก Add New → Project → Import repository
5) Deploy โปรเจกต์
6) สร้าง API key ที่ openrouter.ai แล้วเปิด Vercel Project → Settings → Environment Variables
7) เพิ่ม OPENROUTER_API_KEY เป็นชื่อ และใส่ API key เป็นค่า (อย่าใส่ key ในไฟล์ HTML หรือ GitHub)
8) ถ้าต้องการเลือกโมเดล ให้เพิ่ม AI_MODEL โดยใช้ชื่อโมเดลที่บัญชี OpenRouter ของคุณใช้งานได้
9) Redeploy แล้วเปิด URL ของ Vercel ทดสอบ

ข้อควรทราบ
- API key/โควตาฟรี/โมเดลที่ใช้ฟรีอาจเปลี่ยนได้ ให้ตรวจสอบเงื่อนไขปัจจุบันใน OpenRouter
- หากไม่มีเครดิตหรือโควตา API คำขอวิเคราะห์อาจไม่สำเร็จ
- คำตอบเป็นการประเมินเบื้องต้น ต้องตรวจรถจริงโดยช่างก่อนซ่อม
