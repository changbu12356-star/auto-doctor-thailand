export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { country, make, model, engine, symptom, code, extra } = req.body || {};
  if (!make || !symptom) return res.status(400).json({ error: 'กรุณาระบุยี่ห้อรถและอาการเสีย' });
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'ยังไม่ได้ตั้งค่า OPENROUTER_API_KEY ใน Vercel: Settings → Environment Variables' });
  const currency = country === 'ญี่ปุ่น' ? 'เยนญี่ปุ่น (JPY)' : 'เงินบาท (THB)';
  const prompt = `ช่วยประเมินปัญหารถยนต์อย่างระมัดระวังและตอบเป็นภาษาไทย ข้อมูล: ประเทศ ${country || 'ไม่ระบุ'}; ยี่ห้อ ${make}; รุ่น/ปี ${model || 'ไม่ระบุ'}; เครื่องยนต์/ระยะทาง ${engine || 'ไม่ระบุ'}; อาการ ${symptom}; รหัส OBD2 ${code || 'ไม่มี'}; ข้อมูลเพิ่ม ${extra || 'ไม่มี'}. จัดหัวข้อ: 1) สรุปอาการ 2) สาเหตุที่เป็นไปได้ 3-5 ข้อ เรียงตามลำดับควรตรวจ พร้อมเหตุผลและระดับความมั่นใจโดยประมาณ 3) ขั้นตอนตรวจสอบทีละขั้น รวมถึง OBD2 เมื่อเกี่ยวข้อง 4) สิ่งที่ไม่ควรทำและข้อควรระวัง 5) อะไหล่ที่อาจเกี่ยวข้อง โดยย้ำว่าต้องตรวจยืนยันก่อนเปลี่ยน 6) ช่วงค่าซ่อมคร่าวๆ เป็น ${currency} พร้อมระบุความไม่แน่นอน. ห้ามอ้างว่าตรวจรถจริงแล้ว ห้ามแต่งข้อมูลเฉพาะรุ่นหากไม่แน่ใจ และให้คำแนะนำหยุดขับ/เรียกช่างหากมีความเสี่ยงเกี่ยวกับเบรก พวงมาลัย ความร้อนสูง น้ำมันรั่ว หรือไฟเตือนรุนแรง.`;
  try {
    const upstream = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', 'X-Title': 'Auto Doctor AI' },
      body: JSON.stringify({ model: process.env.AI_MODEL || 'openrouter/auto', messages: [
        { role: 'system', content: 'คุณเป็นผู้ช่วยวิเคราะห์รถยนต์ที่ระมัดระวัง ซื่อสัตย์ และให้ความสำคัญกับความปลอดภัย ต้องระบุความไม่แน่นอนเสมอ' },
        { role: 'user', content: prompt }
      ], temperature: 0.3 })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: data?.error?.message || 'ผู้ให้บริการ AI ตอบกลับผิดพลาด โปรดตรวจ API key โควตา และรุ่นโมเดล' });
    const answer = data?.choices?.[0]?.message?.content;
    if (!answer) return res.status(502).json({ error: 'AI ไม่ได้ส่งคำตอบกลับมา' });
    return res.status(200).json({ answer });
  } catch { return res.status(502).json({ error: 'เชื่อมต่อบริการ AI ไม่สำเร็จ โปรดลองใหม่' }); }
}
